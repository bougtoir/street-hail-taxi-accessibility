# FINAL MANUSCRIPT LENGTH REPORT (LITERATURE_FINAL)

| Section | words | target |
|---|---|---|
| Abstract | 250 | - |
| Introduction | ~1,110 | 1,200-1,500 (approx) |
| Methods | ~1,220 | 1,300-1,600 (approx) |
| Results | ~645 | 1,000-1,300 (kept compact per Phase 7) |
| Discussion | ~1,560 | 1,500-2,000 |
| Conclusion | ~220 | 200-300 |
| Main text total | ~5,010 | 5,000-6,000 |

References: 41. Cover letter: ~640 words, first person, signed Onishi Tatsuki.
